import { useState } from "react";
import { C, hexA } from "./constants.js";
import { useDaisy } from "./hooks/useDaisy.js";

import FluidGL       from "./components/FluidGL.jsx";
import DaisyOrb      from "./components/DaisyOrb.jsx";
import ActionCard    from "./components/ActionCard.jsx";
import OrbPicker     from "./components/OrbPicker.jsx";
import BottomChatTab from "./components/BottomChatTab.jsx";
import SidePanel     from "./components/SidePanel.jsx";
import TopBar        from "./components/TopBar.jsx";

// ─── App ─────────────────────────────────────────────────────────────────────
export default function App() {
  const [mode,     setMode]     = useState("fluid");   // "fluid" | "normal"
  const [orbStyle, setOrbStyle] = useState("glass");   // orb variant
  const [chatSide, setChatSide] = useState(null);      // null | "left" | "right"

  const {
    dstate, messages, input, setInput,
    busy, amp, energy, scrollRef,
    wake, rest, send,
  } = useDaisy();

  const fluid = mode === "fluid";

  return (
    <div style={{
      position: "relative", width: "100%", height: "100vh", minHeight: 560,
      background: C.base, color: C.ink, overflow: "hidden",
      fontFamily: "'Hanken Grotesk', system-ui, sans-serif",
    }}>

      {/* ── Background ─────────────────────────────────────────────────── */}
      {fluid
        ? <FluidGL active={dstate !== "dormant"} energy={energy} />
        : <div style={{ position: "absolute", inset: 0, background: `radial-gradient(120% 90% at 50% -10%, ${C.base2}, ${C.base})` }}/>
      }

      {/* vignette overlay */}
      <div style={{
        position: "absolute", inset: 0, pointerEvents: "none",
        background: `radial-gradient(120% 120% at 50% 50%, transparent 55%, ${hexA("#000000", 0.55)} 100%)`,
      }}/>

      {/* ── Daisy orb + dog morph ─────────────────────────────────────── */}
      {fluid && <DaisyOrb state={dstate} amp={amp} variant={orbStyle} />}

      {/* ── Side panel (when chat is dragged to a side) ───────────────── */}
      {chatSide && (
        <SidePanel
          side={chatSide}
          messages={messages}
          onReset={() => setChatSide(null)}
        />
      )}

      {/* ── Top bar ───────────────────────────────────────────────────── */}
      <TopBar dstate={dstate} mode={mode} setMode={setMode} />

      {/* ── Dormant screen ────────────────────────────────────────────── */}
      <div style={{
        position: "absolute", inset: 0, zIndex: 2,
        display: "flex", flexDirection: "column",
        alignItems: "center", justifyContent: "center",
        padding: "0 20px", textAlign: "center",
        pointerEvents: dstate === "dormant" ? "auto" : "none",
      }}>
        {dstate === "dormant" && (
          <div style={{ animation: "daisyRise .8s ease both" }}>
            <div style={{
              fontFamily: "'Instrument Serif', serif", fontStyle: "italic",
              fontSize: "clamp(34px, 6vw, 64px)", color: C.ink, opacity: 0.92, lineHeight: 1.1,
            }}>
              Hey&nbsp;Daisy
            </div>
            <button
              onClick={wake}
              style={{
                marginTop: 26, cursor: "pointer", pointerEvents: "auto",
                padding: "12px 22px", borderRadius: 999, fontFamily: "inherit",
                color: C.ink, fontSize: 14,
                background: hexA(C.teal, 0.1),
                border: `1px solid ${hexA(C.teal, 0.35)}`,
                backdropFilter: "blur(6px)", transition: "all .25s",
              }}
              onMouseEnter={e => e.currentTarget.style.background = hexA(C.teal, 0.2)}
              onMouseLeave={e => e.currentTarget.style.background = hexA(C.teal, 0.1)}
            >
              tap to wake her — or just start typing
            </button>
          </div>
        )}
      </div>

      {/* ── Chat messages ─────────────────────────────────────────────── */}
      {dstate !== "dormant" && (
        <div
          ref={scrollRef}
          style={{
            position: "absolute", left: "50%", transform: "translateX(-50%)",
            top: 72, bottom: 170, width: "min(640px, 92vw)", zIndex: 4,
            overflowY: "auto", padding: "10px 4px 20px",
            maskImage: "linear-gradient(180deg, transparent, #000 36px, #000 calc(100% - 24px), transparent)",
          }}
        >
          {messages.length === 0 && (
            <div style={{
              textAlign: "center", color: C.inkDim, marginTop: 40,
              fontFamily: "'Instrument Serif', serif", fontStyle: "italic", fontSize: 24, opacity: 0.7,
            }}>
              I'm listening…
            </div>
          )}

          {messages.map((m, i) => (
            <div key={i} className="daisy-msg" style={{
              display: "flex",
              justifyContent: m.who === "me" ? "flex-end" : "flex-start",
              margin: "10px 0",
            }}>
              <div style={{ maxWidth: "82%" }}>
                <div style={{
                  padding: "11px 15px", borderRadius: 18, fontSize: 14.5, lineHeight: 1.5,
                  color:      m.who === "me" ? C.base : C.ink,
                  background: m.who === "me" ? C.tealBright : hexA("#0c2326", 0.66),
                  border:     m.who === "me" ? "none" : `1px solid ${hexA(C.teal, 0.22)}`,
                  borderBottomRightRadius: m.who === "me" ? 6 : 18,
                  borderBottomLeftRadius:  m.who === "me" ? 18 : 6,
                  backdropFilter: "blur(10px)",
                }}>
                  {m.text}
                </div>
                {m.action && <ActionCard a={m.action} />}
              </div>
            </div>
          ))}

          {/* typing indicator */}
          {busy && (
            <div className="daisy-msg" style={{ display: "flex", margin: "10px 0" }}>
              <div style={{
                padding: "13px 16px", borderRadius: 18, borderBottomLeftRadius: 6,
                background: hexA("#0c2326", 0.66),
                border: `1px solid ${hexA(C.teal, 0.22)}`,
                display: "flex", gap: 5,
              }}>
                {[0, 1, 2].map(d => (
                  <span key={d} style={{
                    width: 6, height: 6, borderRadius: 999, background: C.tealBright,
                    animation: `daisyBreathe 1s ease-in-out ${d * 0.18}s infinite`,
                  }}/>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── Bottom dock ───────────────────────────────────────────────── */}
      <div style={{
        position: "absolute", left: 0, right: 0, bottom: 0, zIndex: 6,
        padding: "0 0 20px",
        display: "flex", flexDirection: "column", alignItems: "center",
      }}>
        {/* chat tab or side indicator */}
        {!chatSide
          ? <BottomChatTab messages={messages} onDragToSide={s => setChatSide(s)} />
          : <div style={{ fontSize: 11, color: hexA(C.inkDim, 0.35), marginBottom: 10, letterSpacing: 0.5 }}>
              chats panel · {chatSide} side
            </div>
        }

        {/* input bar row */}
        <div style={{ display: "flex", alignItems: "center", gap: 8, width: "min(640px, 92vw)" }}>

          {/* orb picker (fluid mode only) */}
          {fluid && <OrbPicker orbStyle={orbStyle} setOrbStyle={setOrbStyle} />}

          {/* input pill */}
          <div style={{
            flex: 1, display: "flex", alignItems: "center", gap: 8,
            padding: "8px 8px 8px 18px", borderRadius: 999,
            background: hexA("#06181a", 0.82),
            border: `1px solid ${hexA(C.teal, 0.28)}`,
            backdropFilter: "blur(14px)",
            boxShadow: `0 8px 40px ${hexA("#000", 0.5)}`,
          }}>
            <input
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === "Enter" && send()}
              placeholder="tell Daisy what to do…"
              style={{
                flex: 1, background: "transparent", border: "none", outline: "none",
                color: C.ink, fontSize: 15, fontFamily: "inherit",
              }}
            />
            {dstate !== "dormant" && (
              <button onClick={rest} style={iconBtn(false)}>✕</button>
            )}
            <button onClick={send} style={iconBtn(true)}>↑</button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Shared icon button style ─────────────────────────────────────────────────
function iconBtn(primary) {
  return {
    width: 40, height: 40, borderRadius: 999, flexShrink: 0, cursor: "pointer",
    border:      primary ? "none" : `1px solid ${hexA(C.teal, 0.3)}`,
    background:  primary ? C.tealBright : "transparent",
    color:       primary ? C.base : C.inkDim,
    fontSize: 17, fontWeight: 600, fontFamily: "inherit",
    display: "flex", alignItems: "center", justifyContent: "center",
    transition: "transform .15s",
  };
}
