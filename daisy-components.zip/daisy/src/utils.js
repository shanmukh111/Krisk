// ─── Intent Detection ──────────────────────────────────────────────────────
// Returns an action object if the user's text matches a known intent,
// or null if no intent is detected.
export function guessAction(text) {
  const t = text.toLowerCase();
  if (/(eat|food|hungry|order|zomato|pizza|biryani|dinner|lunch|dosa)/.test(t))
    return { kind: "food",   icon: "🍜", title: "Food",     line: "Finding spots near you" };
  if (/(video|youtube|watch|play|song|music|spotify)/.test(t))
    return { kind: "video",  icon: "▶",  title: "Watch",    line: "Pulling top picks" };
  if (/(message|text|whatsapp|tell|msg|send|ping)/.test(t))
    return { kind: "msg",    icon: "✉",  title: "Message",  line: "Drafting in your tone" };
  if (/(remind|reminder|alarm|wake me|schedule|calendar)/.test(t))
    return { kind: "remind", icon: "◔",  title: "Reminder", line: "Setting it up" };
  if (/(call|dial|phone|ring)/.test(t))
    return { kind: "call",   icon: "☎",  title: "Call",     line: "Opening dialer" };
  return null;
}

// ─── Canned Replies (offline fallback) ─────────────────────────────────────
// Used when the Claude API call fails.
export function cannedReply(text) {
  const a = guessAction(text);
  if (a?.kind === "food")   return "on it — pulling a few good places near you. give me a sec.";
  if (a?.kind === "video")  return "say less. lining up the best videos for that.";
  if (a?.kind === "msg")    return "got it, drafting that in your voice. want me to send or show it first?";
  if (a?.kind === "remind") return "done — I'll nudge you when it's time.";
  if (a?.kind === "call")   return "opening the dialer for you now.";
  return "I'm here. tell me what to do and I'll handle it.";
}
