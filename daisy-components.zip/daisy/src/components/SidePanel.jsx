import { useState, useRef } from "react";
import { C, hexA } from "../constants.js";

// ─── SidePanel ───────────────────────────────────────────────────────────────
// Rendered when the user has dragged the chat tab to a side.
//
// Features:
//   • Resizable — drag the edge handle to change width (160–360px)
//   • Collapsible — click the "chats" tab to hide/show
//   • Drag to bottom — left-click drag the tab toward center to return to bottom
//
// Props:
//   side      — "left" | "right"
//   messages  — full messages array
//   onReset   — callback to return panel to bottom position
//
export default function SidePanel({ side, messages, onReset }) {
  const [open,   setOpen]   = useState(true);
  const [width,  setWidth]  = useState(220);
  const [dragHint, setDragHint] = useState(false);

  const draggingResize = useRef(false);
  const startX         = useRef(0);
  const startW         = useRef(0);

  const isLeft   = side === "left";
  const userMsgs = messages.filter(m => m.who === "me");

  // ── resize handle ──────────────────────────────────────────────────────────
  const onResizeDown = (e) => {
    e.preventDefault(); e.stopPropagation();
    draggingResize.current = true;
    startX.current = e.clientX; startW.current = width;

    const onMove = (ev) => {
      const dx = isLeft
        ? ev.clientX - startX.current
        : startX.current - ev.clientX;
      setWidth(Math.max(160, Math.min(360, startW.current + dx)));
    };

    const onUp = () => {
      draggingResize.current = false;
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup",   onUp);
    };

    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup",   onUp);
  };

  // ── drag tab to bottom ─────────────────────────────────────────────────────
  const onTabDown = (e) => {
    if (e.button !== 0) return;
    e.preventDefault();
    startX.current = e.clientX;

    const onMove = (ev) => {
      const dx = isLeft
        ? ev.clientX - startX.current
        : startX.current - ev.clientX;
      setDragHint(dx > 60);
    };

    const onUp = (ev) => {
      const dx = isLeft
        ? ev.clientX - startX.current
        : startX.current - ev.clientX;
      if (dx > 80) onReset();
      setDragHint(false);
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup",   onUp);
    };

    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup",   onUp);
  };

  return (
    <div style={{
      position: "fixed", top: 72, bottom: 130,
      [isLeft ? "left" : "right"]: 0,
      width: open ? width : 32, zIndex: 20,
      transition: draggingResize.current ? "none" : "width .3s cubic-bezier(.22,1,.36,1)",
      display: "flex",
      flexDirection: isLeft ? "row" : "row-reverse",
      userSelect: "none",
    }}>

      {/* center-drag hint */}
      {dragHint && (
        <div style={{
          position: "fixed", top: "50%", left: "50%",
          transform: "translate(-50%,-50%)", zIndex: 99,
          padding: "10px 20px", borderRadius: 12,
          background: hexA(C.teal, 0.25),
          border: `1px solid ${hexA(C.teal, 0.5)}`,
          color: C.tealBright, fontSize: 13,
          backdropFilter: "blur(10px)", pointerEvents: "none",
        }}>
          release to move back to bottom
        </div>
      )}

      {/* ── tab strip (grab to move, click to toggle) ─────────────────── */}
      <div
        onMouseDown={onTabDown}
        onClick={() => setOpen(o => !o)}
        title="drag toward center → back to bottom  ·  click to toggle"
        style={{
          width: 32, flexShrink: 0, cursor: "grab",
          display: "flex", alignItems: "center", justifyContent: "center",
          background: hexA(C.teal, 0.08),
          borderRadius: isLeft ? "0 10px 10px 0" : "10px 0 0 10px",
          border: `1px solid ${hexA(C.teal, 0.2)}`,
          writingMode: "vertical-rl",
          backdropFilter: "blur(8px)",
          transition: "background .2s",
        }}
        onMouseEnter={e => e.currentTarget.style.background = hexA(C.teal, 0.16)}
        onMouseLeave={e => e.currentTarget.style.background = hexA(C.teal, 0.08)}
      >
        <span style={{
          fontSize: 10.5, color: C.inkDim, letterSpacing: 1.5,
          transform: isLeft ? "rotate(180deg)" : "none",
        }}>
          chats
        </span>
      </div>

      {/* ── panel body ───────────────────────────────────────────────────── */}
      <div style={{
        flex: 1, overflow: "hidden",
        background: hexA("#06181a", 0.9),
        border: `1px solid ${hexA(C.teal, 0.2)}`,
        backdropFilter: "blur(14px)",
        borderRadius: isLeft ? "0 14px 14px 0" : "14px 0 0 14px",
        padding: open ? "14px 10px" : 0,
        display: "flex", flexDirection: "column", gap: 6,
        opacity: open ? 1 : 0,
        transition: "opacity .25s",
        pointerEvents: open ? "auto" : "none",
      }}>
        {/* header */}
        <div style={{
          fontSize: 11, color: C.inkDim, letterSpacing: 1,
          paddingBottom: 8, flexShrink: 0,
          borderBottom: `1px solid ${hexA(C.teal, 0.12)}`,
          display: "flex", justifyContent: "space-between", alignItems: "center",
        }}>
          <span>recent</span>
          <span
            style={{ color: hexA(C.tealBright, 0.5), cursor: "pointer", fontSize: 10 }}
            onClick={onReset}
          >
            ↓ to bottom
          </span>
        </div>

        {/* list */}
        <div style={{ flex: 1, overflowY: "auto", display: "flex", flexDirection: "column", gap: 5 }}>
          {userMsgs.length === 0 ? (
            <div style={{ fontSize: 12, color: hexA(C.inkDim, 0.5), padding: "6px 0", textAlign: "center" }}>
              nothing yet
            </div>
          ) : (
            userMsgs.slice().reverse().map((m, i) => (
              <div
                key={i}
                className="chat-item"
                style={{
                  fontSize: 12.5, color: C.inkDim,
                  padding: "7px 9px", borderRadius: 8,
                  background: hexA(C.teal, 0.06),
                  border: `1px solid ${hexA(C.teal, 0.1)}`,
                  whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
                  cursor: "default",
                }}
              >
                {m.text}
              </div>
            ))
          )}
        </div>
      </div>

      {/* ── resize handle ─────────────────────────────────────────────────── */}
      {open && (
        <div
          onMouseDown={onResizeDown}
          style={{
            position: "absolute",
            [isLeft ? "right" : "left"]: 0,
            top: 0, bottom: 0, width: 8,
            cursor: "ew-resize", zIndex: 5,
            display: "flex", alignItems: "center", justifyContent: "center",
          }}
          onMouseEnter={e => { if (e.currentTarget.children[0]) e.currentTarget.children[0].style.opacity = "1"; }}
          onMouseLeave={e => { if (e.currentTarget.children[0] && !draggingResize.current) e.currentTarget.children[0].style.opacity = "0"; }}
        >
          <div style={{
            width: 3, height: 40, borderRadius: 4,
            background: hexA(C.teal, 0.5), opacity: 0, transition: "opacity .2s",
          }}/>
        </div>
      )}
    </div>
  );
}
