import { useState, useRef } from "react";
import { C, hexA } from "../constants.js";

// ─── BottomChatTab ───────────────────────────────────────────────────────────
// The default chat history tab — sits above the input bar.
//
// Interactions:
//   • Hover          → expands to show recent chats (with glow on each item)
//   • Left-click drag left  → snap to left side panel
//   • Left-click drag right → snap to right side panel
//
// Props:
//   messages      — full messages array from useDaisy
//   onDragToSide  — callback(side: "left"|"right") when dragged to a side
//
export default function BottomChatTab({ messages, onDragToSide }) {
  const [open, setOpen]         = useState(false);
  const [dragHint, setDragHint] = useState(null); // "left" | "right" | null
  const isDragging              = useRef(false);
  const startX                  = useRef(0);

  const userMsgs = messages.filter(m => m.who === "me");

  const onMouseDown = (e) => {
    if (e.button !== 0) return;
    isDragging.current = true;
    startX.current = e.clientX;

    const onMove = (ev) => {
      const dx = ev.clientX - startX.current;
      setDragHint(Math.abs(dx) > 40 ? (dx < 0 ? "left" : "right") : null);
    };

    const onUp = (ev) => {
      const dx = ev.clientX - startX.current;
      if (Math.abs(dx) > 80) onDragToSide(dx < 0 ? "left" : "right");
      isDragging.current = false;
      setDragHint(null);
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup",   onUp);
    };

    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup",   onUp);
  };

  return (
    <div style={{ width: "100%", display: "flex", flexDirection: "column", alignItems: "center", marginBottom: 8 }}>

      {/* drag-to-side hint overlay */}
      {dragHint && (
        <div style={{
          position: "fixed", top: "50%",
          [dragHint === "left" ? "left" : "right"]: 24,
          transform: "translateY(-50%)", zIndex: 99,
          padding: "10px 18px", borderRadius: 12,
          background: hexA(C.teal, 0.22),
          border: `1px solid ${hexA(C.teal, 0.45)}`,
          color: C.tealBright, fontSize: 13,
          backdropFilter: "blur(10px)", pointerEvents: "none",
        }}>
          {dragHint === "left" ? "← snap to left" : "snap to right →"}
        </div>
      )}

      {/* tab area */}
      <div
        onMouseDown={onMouseDown}
        onMouseEnter={() => setOpen(true)}
        onMouseLeave={() => { if (!isDragging.current) setOpen(false); }}
        style={{ width: "min(640px,92vw)", cursor: "grab", userSelect: "none" }}
      >
        {/* label row — always visible */}
        <div style={{
          textAlign: "center", padding: "6px 0 4px", letterSpacing: 1.5,
          display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
          color: open ? C.tealBright : C.inkDim, fontSize: 11.5,
          transition: "color .2s",
          textShadow: open ? `0 0 12px ${C.tealBright}` : "none",
        }}>
          <div style={{
            flex: 1, height: 1,
            background: open
              ? `linear-gradient(to right, transparent, ${hexA(C.tealBright, 0.3)})`
              : `linear-gradient(to right, transparent, ${hexA(C.teal, 0.12)})`,
            transition: "background .2s",
          }}/>
          <span>chats</span>
          <span style={{ fontSize: 9.5, color: hexA(C.inkDim, 0.4), fontWeight: 400 }}>
            drag left or right to move
          </span>
          <div style={{
            flex: 1, height: 1,
            background: open
              ? `linear-gradient(to left, transparent, ${hexA(C.tealBright, 0.3)})`
              : `linear-gradient(to left, transparent, ${hexA(C.teal, 0.12)})`,
            transition: "background .2s",
          }}/>
        </div>

        {/* expandable panel */}
        <div style={{
          overflow: "hidden",
          transition: "max-height .35s cubic-bezier(.22,1,.36,1), opacity .25s",
          maxHeight: open ? 220 : 0,
          opacity: open ? 1 : 0,
        }}>
          <div style={{
            borderRadius: 14, padding: "10px 12px", marginBottom: 6,
            background: hexA("#06181a", 0.85),
            border: `1px solid ${hexA(C.teal, 0.22)}`,
            backdropFilter: "blur(14px)",
            display: "flex", flexDirection: "column", gap: 5,
            boxShadow: `0 -8px 30px ${hexA(C.teal, 0.06)}`,
          }}>
            {userMsgs.length === 0 ? (
              <div style={{ fontSize: 13, color: C.inkDim, padding: 8, textAlign: "center" }}>
                no chats yet — say something
              </div>
            ) : (
              userMsgs.slice(-6).reverse().map((m, i) => (
                <div
                  key={i}
                  className="chat-item"
                  style={{
                    fontSize: 13, color: C.inkDim,
                    padding: "8px 10px", borderRadius: 10,
                    background: hexA(C.teal, 0.06),
                    border: `1px solid ${hexA(C.teal, 0.1)}`,
                    whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
                    cursor: "default",
                  }}
                >
                  {m.text}
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
