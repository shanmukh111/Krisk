import { useRef, useEffect, useState } from "react";
import { C, hexA } from "../constants.js";

// ─── FluidGL ────────────────────────────────────────────────────────────────
// Real-time WebGL fluid background using fractional Brownian motion (fbm).
// Falls back to a plain radial gradient if WebGL is unavailable.
//
// Props:
//   active  — boolean, speeds up fluid when Daisy is awake
//   energy  — ref (0–1), drives brightness of the fluid
//
export default function FluidGL({ active, energy }) {
  const ref       = useRef(null);
  const raf       = useRef(0);
  const activeRef = useRef(active);
  activeRef.current = active;

  const [fallback, setFallback] = useState(false);

  useEffect(() => {
    const cv = ref.current;
    if (!cv) return;

    const gl = cv.getContext("webgl") || cv.getContext("experimental-webgl");
    if (!gl) { setFallback(true); return; }

    // ── shaders ─────────────────────────────────────────────────────────────
    const vsrc = "attribute vec2 p; void main(){ gl_Position = vec4(p,0.0,1.0); }";

    const fsrc = `
      precision highp float;
      uniform vec2  u_res;
      uniform float u_time;
      uniform float u_energy;

      float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1,311.7)))*43758.5453); }
      float noise(vec2 p){
        vec2 i=floor(p), f=fract(p);
        float a=hash(i), b=hash(i+vec2(1,0)), c=hash(i+vec2(0,1)), d=hash(i+vec2(1,1));
        vec2 u=f*f*(3.0-2.0*f);
        return mix(mix(a,b,u.x), mix(c,d,u.x), u.y);
      }
      float fbm(vec2 p){
        float v=0.0, a=0.5;
        for(int i=0;i<5;i++){ v+=a*noise(p); p*=2.0; a*=0.5; }
        return v;
      }

      void main(){
        vec2 uv  = gl_FragCoord.xy / u_res.xy;
        vec2 asp = vec2(u_res.x/u_res.y, 1.0);
        vec2 p   = uv * asp * 2.4;
        float t  = u_time * 0.04;

        vec2 q = vec2(fbm(p+t),            fbm(p+vec2(5.2,1.3)-t));
        vec2 r = vec2(fbm(p+3.5*q+vec2(1.7,9.2)+t*0.5),
                      fbm(p+3.5*q+vec2(8.3,2.8)-t*0.4));
        float f = fbm(p + 3.5*r);

        vec3 deep   = vec3(0.012, 0.031, 0.039);
        vec3 teal   = vec3(0.204, 0.627, 0.643);
        vec3 bright = vec3(0.384, 0.909, 0.878);
        vec3 purple = vec3(0.353, 0.247, 0.478);

        vec3 col = deep;
        col = mix(col, teal,   smoothstep(0.25, 0.95, f));
        col = mix(col, bright, pow(max(f,0.0), 3.0) * (0.5 + u_energy * 0.22));
        col = mix(col, purple, smoothstep(0.15, 0.45, r.x*r.y) * 0.10);

        float vig = smoothstep(1.25, 0.25, length(uv - 0.5));
        col *= 0.45 + 0.55 * vig;
        gl_FragColor = vec4(col, 1.0);
      }`;

    // ── compile & link ───────────────────────────────────────────────────────
    const sh = (type, src) => {
      const s = gl.createShader(type);
      gl.shaderSource(s, src); gl.compileShader(s); return s;
    };
    const prog = gl.createProgram();
    gl.attachShader(prog, sh(gl.VERTEX_SHADER,   vsrc));
    gl.attachShader(prog, sh(gl.FRAGMENT_SHADER, fsrc));
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) { setFallback(true); return; }
    gl.useProgram(prog);

    const buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1,-1, 3,-1, -1,3]), gl.STATIC_DRAW);
    const loc = gl.getAttribLocation(prog, "p");
    gl.enableVertexAttribArray(loc);
    gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);

    const uRes  = gl.getUniformLocation(prog, "u_res");
    const uTime = gl.getUniformLocation(prog, "u_time");
    const uEn   = gl.getUniformLocation(prog, "u_energy");

    let en = 0;
    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 1.75);
      cv.width = cv.clientWidth * dpr; cv.height = cv.clientHeight * dpr;
      gl.viewport(0, 0, cv.width, cv.height);
    };
    resize();
    window.addEventListener("resize", resize);

    const start = performance.now();
    const loop = () => {
      en += ((energy.current || 0) - en) * 0.06;
      gl.uniform2f(uRes,  cv.width, cv.height);
      gl.uniform1f(uTime, (performance.now() - start) / 1000);
      gl.uniform1f(uEn,   activeRef.current ? en : en * 0.5);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
      raf.current = requestAnimationFrame(loop);
    };
    loop();

    return () => {
      cancelAnimationFrame(raf.current);
      window.removeEventListener("resize", resize);
    };
  }, []);

  if (fallback) {
    return (
      <div style={{
        position: "absolute", inset: 0,
        background: `radial-gradient(120% 90% at 50% -10%, ${C.base2}, ${C.base})`,
      }}/>
    );
  }

  return (
    <canvas
      ref={ref}
      style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}
    />
  );
}
