import { C, hexA } from "../constants.js";
import OrbBody from "./OrbBody.jsx";

// ─── Ring ────────────────────────────────────────────────────────────────────
// Ripple ring shown while Daisy is listening or speaking.
function Ring({ delay, amp }) {
  return (
    <div style={{
      position: "absolute", inset: 30, borderRadius: "50%",
      border: `1px solid ${hexA(C.tealBright, 0.5)}`,
      animation: `daisyRipple 1.8s ease-out ${delay}s infinite`,
      opacity: 0.4 + amp * 0.4,
    }}/>
  );
}

// ─── DaisyOrb ───────────────────────────────────────────────────────────────
// The central visual: a stylized 3D dog face that morphs into a liquid orb.
//
// State transitions:
//   dormant    → invisible (scale 0.2, opacity 0)
//   waking     → dog face appears, then dissolves into orb
//   listening  → orb pulses with ripple rings
//   thinking   → orb spins faster
//   speaking   → orb expands with amp
//   idleActive → orb rests at 0.92 scale
//
// Props:
//   state   — current dstate string
//   amp     — 0–1 amplitude from useDaisy (drives orb scale)
//   variant — orb style from OrbBody
//
export default function DaisyOrb({ state, amp, variant }) {
  const visible = state !== "dormant";
  const isDog   = state === "waking";

  const scale =
    state === "dormant"    ? 0.2 :
    state === "thinking"   ? 1.04 :
    state === "speaking"   ? 1 + amp * 0.16 :
    state === "listening"  ? 1 + amp * 0.1 :
    0.92;

  return (
    <div style={{
      position: "absolute", inset: 0,
      display: "flex", alignItems: "center", justifyContent: "center",
      pointerEvents: "none",
    }}>
      <div style={{
        position: "relative", width: 280, height: 280,
        transform: `scale(${scale})`,
        opacity: visible ? 1 : 0,
        transition: "transform .7s cubic-bezier(.22,1,.36,1), opacity .9s ease",
      }}>

        {/* ── Dog face (visible only during waking morph) ───────────────── */}
        <svg
          viewBox="0 0 200 200" width="280" height="280"
          style={{
            position: "absolute", inset: 0,
            opacity: isDog ? 1 : 0,
            filter: isDog ? "blur(0px)" : "blur(14px)",
            transform: isDog ? "scale(1)" : "scale(1.12)",
            transition: "opacity .9s ease, filter .9s ease, transform .9s ease",
          }}
        >
          <defs>
            <radialGradient id="dface" cx="50%" cy="45%" r="60%">
              <stop offset="0%"   stopColor={C.tealBright} />
              <stop offset="60%"  stopColor={C.teal} />
              <stop offset="100%" stopColor={C.tealDeep} />
            </radialGradient>
          </defs>

          {/* ears */}
          <path d="M52 60 Q34 18 64 36 Q70 52 66 72 Z"   fill="url(#dface)" opacity="0.85"/>
          <path d="M148 60 Q166 18 136 36 Q130 52 134 72 Z" fill="url(#dface)" opacity="0.85"/>

          {/* head */}
          <ellipse cx="100" cy="108" rx="58" ry="56" fill="url(#dface)"/>

          {/* snout */}
          <ellipse cx="100" cy="132" rx="30" ry="26" fill={C.tealDeep} opacity="0.55"/>

          {/* eyes */}
          <circle cx="80"  cy="98" r="8"   fill="#eafffd"/>
          <circle cx="120" cy="98" r="8"   fill="#eafffd"/>
          <circle cx="80"  cy="98" r="3.2" fill={C.base}/>
          <circle cx="120" cy="98" r="3.2" fill={C.base}/>

          {/* nose */}
          <ellipse cx="100" cy="126" rx="9" ry="7"
            fill="#06222200" stroke="#cffffb" strokeWidth="2"/>
        </svg>

        {/* ── Ripple rings ─────────────────────────────────────────────── */}
        {(state === "listening" || state === "speaking") && (
          <>
            <Ring delay={0}   amp={amp} />
            <Ring delay={0.9} amp={amp} />
          </>
        )}

        {/* ── Orb (hidden during dog morph, shown otherwise) ───────────── */}
        <div style={{
          position: "absolute",
          inset:   isDog ? 70 : 36,
          opacity: isDog ? 0 : 1,
          transition: "opacity .9s ease, inset .9s cubic-bezier(.22,1,.36,1)",
        }}>
          <OrbBody variant={variant} state={state} />
        </div>
      </div>
    </div>
  );
}
