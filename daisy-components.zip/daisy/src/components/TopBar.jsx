import { C, hexA } from "../constants.js";

// ─── TopBar ──────────────────────────────────────────────────────────────────
// Fixed top bar — shows Daisy name + status dot + fluid/normal mode toggle.
//
// Props:
//   dstate  — current state string (affects status dot color/animation)
//   mode    — "fluid" | "normal"
//   setMode — setter
//
export default function TopBar({ dstate, mode, setMode }) {
  const isDormant = dstate === "dormant";

  return (
    <div style={{
      position: "absolute", top: 0, left: 0, right: 0, zIndex: 5,
      display: "flex", alignItems: "center", justifyContent: "space-between",
      padding: "18px 22px",
    }}>
      {/* left: status dot + name */}
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <div style={{
          width: 9, height: 9, borderRadius: 999,
          background:  isDormant ? C.inkDim : C.tealBright,
          boxShadow:   isDormant ? "none"   : `0 0 12px ${C.tealBright}`,
          animation:   isDormant ? "none"   : "daisyBreathe 2.4s ease-in-out infinite",
        }}/>
        <span style={{ fontFamily: "'Instrument Serif', serif", fontSize: 22, letterSpacing: 0.5 }}>
          Daisy
        </span>
      </div>

      {/* right: fluid / normal toggle */}
      <div style={{
        display: "flex", padding: 3, borderRadius: 999,
        background: hexA(C.teal, 0.06),
        border: `1px solid ${hexA(C.teal, 0.2)}`,
        fontSize: 12.5,
      }}>
        {["fluid", "normal"].map(m => (
          <button
            key={m}
            onClick={() => setMode(m)}
            style={{
              border: "none", cursor: "pointer", padding: "6px 14px", borderRadius: 999,
              color:       mode === m ? C.base   : C.inkDim,
              background:  mode === m ? C.tealBright : "transparent",
              fontWeight:  mode === m ? 600 : 400,
              transition: "all .25s", textTransform: "capitalize", fontFamily: "inherit",
            }}
          >
            {m}
          </button>
        ))}
      </div>
    </div>
  );
}
